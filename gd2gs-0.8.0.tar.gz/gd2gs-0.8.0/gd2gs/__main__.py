""" gd2gs main """

from gd2gs import main        # pylint: disable=no-name-in-module

if __name__ == '__main__':
    main()
